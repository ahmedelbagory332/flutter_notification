<?php 
	define('DB_USERNAME','id15332968_root');
	define('DB_PASSWORD','Diff_android288');
	define('DB_NAME','id15332968_fcm');
	define('DB_HOST','localhost');

	//defined a new constant for firebase api key
	define('FIREBASE_API_KEY', 'AAAAORKyfTQ:APA91bFs1eoheJMBEF81YV4QSaHNXV3er88ZcJw2pK-OnRkVQckqrdAhkpKVXsaVGX5cTjy2AC46Kif1OAdQef0HHJn9vKTjE1EqfRZFFvji2jhBGuKTEAP2WOyyUVilJgjUg5Ljagt8');

	